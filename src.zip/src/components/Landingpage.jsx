import React from 'react';
import HeroTeamImage from '../assets/Hero1.avif';
import './Landingpge.css'
import Button from 'react-bootstrap/Button';


function Landingpage() {
  return (
    <>
      <div className='microsoftheding'
        style={{
          width: '100vw',
          height: '100vh',
          backgroundImage: `url(${HeroTeamImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className='row text1'>
          <div className='microlist col-md-12 col-lg-6 bg-dark'>
            <h4 className="Microsofttext">The new Microsoft Teams is now available</h4>
            <p className="Microsofttextp">Collaborate more effectively with a faster, simpler,
            <br />
            smarter, and more flexible Teams.</p>
            <Button   variant="primary" className='Microsofttextbtn'>Download Now</Button>
            <Button variant="outline-primary ms-3">Learn about the new Microsoft Teams</Button>{' '}
          </div>
          {/* <div className="col-lg-6 col-md-12" ></div> */}
        </div>
      </div>




    </>
  );
}

export default Landingpage;
